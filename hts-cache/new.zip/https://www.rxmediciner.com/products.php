<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/png" href="https://www.rxmediciner.com/images/favicon.png"/>
<script type="text/javascript" src="https://www.rxmediciner.com/js/jquery-1.11.2.min.js?v=481441647"></script>
<script type="text/javascript" src="https://www.rxmediciner.com/js/typeahead.js"></script>
<link rel="stylesheet" type="text/css" href="https://www.rxmediciner.com/css/font-awesome.min.css?v=511708841" />
<link rel="stylesheet" type="text/css" href="https://www.rxmediciner.com/css/owl.carousel.css?v=1679372768" />
<link rel="stylesheet" type="text/css" href="https://www.rxmediciner.com/css/bootstrap.min.css?v=833193831" />
<link rel="stylesheet" type="text/css" href="https://www.rxmediciner.com/css/slicknav.min.css?v=1214893170" />
<link rel="stylesheet" type="text/css" href="https://www.rxmediciner.com/css/style.css?v=955186463" />
<link rel="stylesheet" type="text/css" href="https://www.rxmediciner.com/css/responsive.css?v=504291746" />
<link rel="stylesheet" href="https://www.rxmediciner.com/css/toastr.css" />
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-167326560-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-167326560-1');
</script>

<meta name="google-site-verification" content="XOE9tasUYgs1AMPQTnAfXe8GIxNqGWIGkEAZRqTtyRk" />	<title>Alla produkter | Rx Mediciner</title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
</head>
<body>
    <style>
    .typeahead { border: 2px solid #FFF;border-radius: 4px;padding: 8px 12px;max-width: 300px;min-width: 290px;background: rgba(66, 52, 52, 1);color: #FFF;}
    .tt-menu { width:300px; }
    ul.typeahead{margin:0px;padding: 0px;list-style-type: none;}
    ul.typeahead.dropdown-menu2 li a {padding: 10px !important;  border-bottom:#CCC 1px solid;color:#FFF;display: inline-block;width: 100%}
    ul.typeahead.dropdown-menu2 li:last-child a { border-bottom:0px !important; }
    .bgcolor {max-width: 550px;min-width: 290px;max-height:340px;background:url("world-contries.jpg") no-repeat center center;padding: 100px 10px 130px;border-radius:4px;text-align:center;margin:10px;}
    .demo-label {font-size:1.5em;color: #686868;font-weight: 500;color:#FFF;}
    .dropdown-menu2>.active>a, .dropdown-menu2>.active>a:focus, .dropdown-menu2>.active>a:hover{text-decoration: none;background-color: #12aef7;outline: 0;}
    .dropdown-menu2{position: absolute;}
    </style>
<header class="main_header">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <div class="top-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <marquee><b>Vi accepterar betalning med swish</b></marquee>
                </div>
            </div>
        </div>
    </div>
    <div class="header_top_area" style="display:none">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="header_top">
                        <ul>
                            <!--<li><a href="tel:+46-76894030"><i class="fa fa-phone"></i> +46-76894030</a></li>-->
                            <li><a href="mailto:rxmedicinar@gmail.com"><i class="fa fa-envelope"></i> rxmedicinar@gmail.com</a></li>
                        </ul>

                        <ul class="pull-right">
                            <!--<li><a href="mailto:"><i class="fa fa-envelope"></i> </a></li>-->
                            <!--<li><a href="" target="_blank"><i class="fa fa-twitter"></i></a></li>-->
                            <!--<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>-->
                            <!--
                            
                            <li><a href="" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="" target="_blank"><i class="fa fa-youtube-play"></i></a></li>-->
                        </ul>
                    </div>
                </div>
            </div>
        </div>	
    </div>
    <div class="header">
        <div class="container">
            <div class="row">
                    <div class="logo_contact_info_part">
                        <div class="col-md-3">
                            <div class="logo">
                                <a href="https://www.rxmediciner.com"><img src="https://www.rxmediciner.com/images/logo.png" alt="RX Mediciner" title="" /></a>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="cont_info">
                                <div class="week">
                                    <img src="https://www.rxmediciner.com/images/date_icon.png" alt="date" />
                                    <p>Mån till sätta <br><span>24*7</span> </p>
                                </div>
                                <!--<div class="call_us">
                                    <img src="https://www.rxmediciner.com/images/mobile_icon.png" alt="date" />
                                    <p>Ringa oss <br><span>+46-76894030</span> </p>
                                </div>-->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <ul class="booking_cart">
                                <!--
                                                            <li class="book_now"><a href="https://www.rxmediciner.com/login.php">Logga in</a></li>
                                                                -->
                                <li class="book_now"><a href="https://www.rxmediciner.com/contact.php">INQUIRE NU</a></li>
                                <!--<li class="book_now">
                                    <a class="CartSlide" href="javascript:void(0);">Vagn (<small id="id-cart-value">2PCS * KR 10</small>)</a>
                                </li> -->
                            </ul>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    <div class="nav_search_area hidden-xs">
        <div class="container">
            <div class="menu_area">
                <div class="col-md-9">	
                    <div class="nav_part">
                        <nav class="navbar navbar-default">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="main_menu">
                                        <div class="navbar-header">
                                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                                <span class="sr-only">Toggle navigation</span>
                                                <span class="icon-bar"></span>
                                                <span class="icon-bar"></span>
                                                <span class="icon-bar"></span>
                                            </button>	
                                        </div>
                                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                            <ul class="nav navbar-nav">
                                                <li ><a href="https://www.rxmediciner.com">Hem</a></li>
                                                <li ><a href="https://www.rxmediciner.com/about.php">Om oss</a></li>
                                                <li ><a href="javascript:void(0);">kategorier</a>
                                                    <ul class="submenu">
                                                            
                                                        <li><a href="https://www.rxmediciner.com/category/antibiotika">Antibiotika</a></li>
                                                            
                                                        <li><a href="https://www.rxmediciner.com/category/blodtryck-och-diabetiker">Blodtryck och diabetiker</a></li>
                                                            
                                                        <li><a href="https://www.rxmediciner.com/category/smn-och-smnlshet">SÃ¶mn och sÃ¶mnlÃ¶shet</a></li>
                                                            
                                                        <li><a href="https://www.rxmediciner.com/category/anabola-steroider">Anabola Steroider</a></li>
                                                            
                                                        <li><a href="https://www.rxmediciner.com/category/stimulantia">Stimulantia</a></li>
                                                            
                                                        <li><a href="https://www.rxmediciner.com/category/opioider">Opioider</a></li>
                                                            
                                                        <li><a href="https://www.rxmediciner.com/category/depression-och-ngest">Depression och Ã¥ngest</a></li>
                                                                                                            </ul>
                                                </li>
                                                <li class="active"><a href="https://www.rxmediciner.com/products.php">Alla produkter</a></li>
                                                <li ><a href="https://www.rxmediciner.com/blog.php">Bloggar</a></li>
                                                <li ><a href="https://www.rxmediciner.com/contact.php">kontakta oss</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="search">
                        <form class="navbar-form navbar-left" role="search" method="post" action="https://www.rxmediciner.com/search_product.php">
                            <div class="form-group">
                                <input type="text" id="src_field" name="keywords" class="form-control typeahead" placeholder="Skriv här">
                                <input type="submit" id="src_btn" value="Sök"/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>


<div class="box">
<!--    <div class="CartSlide closebtn">X</div>-->
    <div class="box-inner" id="cartModel">Loading...</div>
    </div>    
    <section class="breadcrum">
        <div class="bread_cumbs">
            <div class="container">
                <div class="page_title_breadcumbs">
                    <ul>
                        <li><a href="https://www.rxmediciner.com">Hem</a>»</li>
                        <li>Alla produkter</li>
                    </ul>
                </div>			
            </div>
        </div>
    </section>
    
    <section class="services_area">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <span class="heading">Alla produkter</span>
                </div>
                
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/ketamine">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/604764cb840f3WhatsApp Image 2021-03-08 at 1.24.35 PM.jpeg" alt="Ketamine" title="Ketamine">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Ketamine</h3>
                            <span class="price">SEK(kr 200 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/oxycontin-40-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5fb4cf2e3993doxycontin 40 mg.jpg" alt="OxyContin 40 mg" title="OxyContin 40 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>OxyContin 40 mg</h3>
                            <span class="price">SEK(kr 1860 - kr 3270)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/oxynorm-20mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5fb4cda5abab7oxynorm 20.png" alt="OxyNorm 20mg" title="OxyNorm 20mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>OxyNorm 20mg</h3>
                            <span class="price">SEK(kr 1863 - kr 3200)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/valium-10-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5cfe47fb40709valium_10-750x750.jpeg" alt="Valium 10 mg" title="Valium 10 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Valium 10 mg</h3>
                            <span class="price">SEK(kr 1890 - kr 2710)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/viagra-100-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5cfe47ad5e194download (7).jpg" alt="Viagra 100 mg" title="Viagra 100 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Viagra 100 mg</h3>
                            <span class="price">SEK(kr 1873 - kr 2700)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/stesolid-10-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5cfe4754ccc35download (6).jpg" alt="Stesolid 10 mg" title="Stesolid 10 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Stesolid 10 mg</h3>
                            <span class="price">SEK(kr 1870 - kr 3115)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/ambien-zolpidem-10-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5d03c610d3502Ambien 10mg-766x1000.jpg" alt="Ambien Zolpidem 10 mg" title="Ambien Zolpidem 10 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Ambien Zolpidem 10 mg</h3>
                            <span class="price">SEK(kr 1865 - kr 2680)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/stilnox-10-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5cfe466eaa63ddownload (5).jpg" alt="Stilnox 10 mg" title="Stilnox 10 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Stilnox 10 mg</h3>
                            <span class="price">SEK(kr 1830 - kr 2705)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/zopiclone-7-5-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5f17cef36b422Zopiclone-for-sale.jpg" alt="Zopiclone 7.5 mg" title="Zopiclone 7.5 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Zopiclone 7.5 mg</h3>
                            <span class="price">SEK(kr 1875 - kr 2730)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/stilnoct-10mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5cfe45f239395download (3).jpg" alt="Stilnoct 10mg" title="Stilnoct 10mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Stilnoct 10mg</h3>
                            <span class="price">SEK(kr 1873 - kr 2765)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/kamagra-100mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5cfe45b5118baKamagra-Tablets.jpg" alt="Kamagra 100mg" title="Kamagra 100mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Kamagra 100mg</h3>
                            <span class="price">SEK(kr 1832 - kr 2705)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/levaxin-150mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5cfe458347280download (2).jpg" alt="Levaxin 150mg" title="Levaxin 150mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Levaxin 150mg</h3>
                            <span class="price">SEK(kr 1863 - kr 2710)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/levitra-20-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5cfe45159759cdownload (1).jpg" alt="Levitra 20 Mg" title="Levitra 20 Mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Levitra 20 Mg</h3>
                            <span class="price">SEK(kr 1800 - kr 2680)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/concerta">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5cfe44b4200fa0750110990416L.jpg" alt="Concerta" title="Concerta">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Concerta</h3>
                            <span class="price">SEK(kr 1770 - kr 2586)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/dukoral">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5cfe442774285Dukoral-Package-full-set-RoW-2016v2-1400x790.jpg" alt="Dukoral" title="Dukoral">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Dukoral</h3>
                            <span class="price">SEK(kr 1710 - kr 2489)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/imovane">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5cfe43db64299imovane.jpg" alt="Imovane" title="Imovane">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Imovane</h3>
                            <span class="price">SEK(kr 1853 - kr 3730)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/tradolan">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5cfe4325524cddokteronline-tradolan-1329-3-1467801602.jpg" alt="Tradolan" title="Tradolan">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Tradolan</h3>
                            <span class="price">SEK(kr 1890 - kr 2800)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/testogel">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5cfe42ed8f469Testogel.jpg" alt="Testogel" title="Testogel">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Testogel</h3>
                            <span class="price">SEK(kr 1863 - kr 3100)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/dalacin-c">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5cfe42ae58eda5cfdda67f40a3dalacin-c.jpg" alt="Dalacin C" title="Dalacin C">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Dalacin C</h3>
                            <span class="price">SEK(kr 1690 - kr 2450)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/klonazepam-klonopin-2-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bbe72fb8adf2klonopin 2mg.jpg" alt="klonazepam (klonopin 2 mg)" title="klonazepam (klonopin 2 mg)">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>klonazepam (klonopin 2 mg)</h3>
                            <span class="price">SEK(kr 1830 - kr 3220)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/cefalexin-250-500-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb46e1277255cephalexin-anty bio.jpg" alt="Cefalexin 250/500 mg" title="Cefalexin 250/500 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Cefalexin 250/500 mg</h3>
                            <span class="price">SEK(kr 29 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/disal-50mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb46c5576d57disal-50mg blood presure.jpg" alt="Disal 50mg" title="Disal 50mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Disal 50mg</h3>
                            <span class="price">SEK(kr 1760 - kr 2570)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/hydroklortiazid-25-50-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb46a015016aHydrochlorothiazide.jpg" alt="Hydroklortiazid 25/50 mg" title="Hydroklortiazid 25/50 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Hydroklortiazid 25/50 mg</h3>
                            <span class="price">SEK(kr 45 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/furosemiden-20mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb46a81e1a59furosemide-20mg diabetis.jp.jpg" alt="Furosemiden 20mg" title="Furosemiden 20mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Furosemiden 20mg</h3>
                            <span class="price">SEK(kr 36 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/doxycyklin-50-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb4658dba39bdoxycycline 50mg anty bio.jpg" alt="Doxycyklin 50 mg" title="Doxycyklin 50 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Doxycyklin 50 mg</h3>
                            <span class="price">SEK(kr 29 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/azitromycin-250-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb3f00466c98AZITHROMYCIN-250MG-TABS anty bio.jpg" alt="Azitromycin 250 mg" title="Azitromycin 250 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Azitromycin 250 mg</h3>
                            <span class="price">SEK(kr 27 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/amoxicilina-500mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb3ee81d3575Amoxicilina 500mg anti bioticts.jpg" alt="Amoxicilina 500mg" title="Amoxicilina 500mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Amoxicilina 500mg</h3>
                            <span class="price">SEK(kr 26 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/opana-40mgg74">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb373b0af3e2opana 40mg(G 17).jpg" alt="Opana 40mg(G74)" title="Opana 40mg(G74)">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Opana 40mg(G74)</h3>
                            <span class="price">SEK(kr 1980 - kr 3410)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/diazepam-10mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb369e6355b0Diazapam 10m5.jpg" alt="Diazepam 10mg" title="Diazepam 10mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Diazepam 10mg</h3>
                            <span class="price">SEK(kr 1890 - kr 3290)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/rohypnol">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb367e526a26ROHYPNOL.jpg" alt="Rohypnol" title="Rohypnol">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Rohypnol</h3>
                            <span class="price">SEK(kr 1873 - kr 2685)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/dilaudid-8mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb33388c7ce3dilaudid-8mg-2.jpg" alt="Dilaudid 8mg" title="Dilaudid 8mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Dilaudid 8mg</h3>
                            <span class="price">SEK(kr 1863 - kr 3300)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/methaqualone-quaalude-300">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb333b0e0edbMandrax-Quaalude.jpg" alt="Methaqualone (quaalude) 300" title="Methaqualone (quaalude) 300">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Methaqualone (quaalude) 300</h3>
                            <span class="price">SEK(kr 1890 - kr 3220)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/pure-a-pvp-crystals">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb32b01d5709A PVP crystals.jpg" alt="Pure A-Pvp Crystals" title="Pure A-Pvp Crystals">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Pure A-Pvp Crystals</h3>
                            <span class="price">SEK(kr 2400 - kr 6200)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/dexedrine-15mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb2a75c84cdbDexedrine.jpg" alt="Dexedrine 15mg" title="Dexedrine 15mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Dexedrine 15mg</h3>
                            <span class="price">SEK(kr 1863 - kr 2692)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/ritalin-20-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb2a4fd023efretalin 20mg.jpg" alt="Ritalin 20 mg" title="Ritalin 20 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Ritalin 20 mg</h3>
                            <span class="price">SEK(kr 1860 - kr 2650)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/xanax-gul-rd-och-grna-barer">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb288a8ab134xanax yellow.jpg" alt="Xanax gul / rÃ¶d och grÃ¶na barer" title="Xanax gul / rÃ¶d och grÃ¶na barer">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Xanax gul / rÃ¶d och grÃ¶na barer</h3>
                            <span class="price">SEK(kr 1863 - kr 3210)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/ritalin-20mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb28661e9e90retalin 20mg.jpg" alt="Ritalin 20mg" title="Ritalin 20mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Ritalin 20mg</h3>
                            <span class="price">SEK(kr 1852 - kr 3100)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/adderall-30mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb285561433dadderall 30mg.jpg" alt="Adderall 30mg" title="Adderall 30mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Adderall 30mg</h3>
                            <span class="price">SEK(kr 1859 - kr 3230)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/rohypnol-1-2-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb251cbeb665ROHYPNOL.jpg" alt="Rohypnol 1/2 mg" title="Rohypnol 1/2 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Rohypnol 1/2 mg</h3>
                            <span class="price">SEK(kr 1872 - kr 3245)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/seconal-sodium">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb250baa9e6dseconal.jpg" alt="Seconal Sodium" title="Seconal Sodium">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Seconal Sodium</h3>
                            <span class="price">SEK(kr 27 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/roxycodon-30-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb24fb25b80eRoxicodone.jpg" alt="Roxycodon 30 mg" title="Roxycodon 30 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Roxycodon 30 mg</h3>
                            <span class="price">SEK(kr 1863 - kr 2690)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/oxycontin-80mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb248fdb87ecoxycontin 80mg.jpg" alt="Oxycontin 80mg" title="Oxycontin 80mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Oxycontin 80mg</h3>
                            <span class="price">SEK(kr 2230 - kr 3020)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/kodein">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb24ad98676bpurple actavis.jpg" alt="Kodein" title="Kodein">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Kodein</h3>
                            <span class="price">SEK(kr 2100.01 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/methadol">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5b7e64808c01bMethadol_stereoisomers.tif.jpg" alt="Methadol" title="Methadol">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Methadol</h3>
                            <span class="price">SEK(kr 20.37 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/benzedrine-sulfate">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5b7e6347ad52b4ffa737b417e7a63a15a8a4e9587e5fb.jpg" alt="Benzedrine Sulfate" title="Benzedrine Sulfate">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Benzedrine Sulfate</h3>
                            <span class="price">SEK(kr 62 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/adderall">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a671a03a054ca97276_3196151008_070662c101_b.jpg" alt="Adderall" title="Adderall">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Adderall</h3>
                            <span class="price">SEK(kr 1870 - kr 2700)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/suboxone-8mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5b06d3b88f810subutex-subuxone-8mg-2335300.jpg" alt="Suboxone 8mg" title="Suboxone 8mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Suboxone 8mg</h3>
                            <span class="price">SEK(kr 1970 - kr 2840)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/subutex-8mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a671b95a270asubutex-8mg-2201042.jpeg" alt="Subutex 8mg" title="Subutex 8mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Subutex 8mg</h3>
                            <span class="price">SEK(kr 1920 - kr 3550)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/vicodin">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a671bc57174e7320670_f496.jpg" alt="Vicodin" title="Vicodin">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Vicodin</h3>
                            <span class="price">SEK(kr 1870 - kr 2680)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/tramadol-100mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a671bf5a2289tramadol.jpg" alt="Tramadol 100mg" title="Tramadol 100mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Tramadol 100mg</h3>
                            <span class="price">SEK(kr 1760 - kr 2630)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/percocet-10mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb33140f1fe5percs.jpg" alt="Percocet 10mg" title="Percocet 10mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Percocet 10mg</h3>
                            <span class="price">SEK(kr 39 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/oxycodone">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb2469be214foxy30mg.jpg" alt="Oxycodone" title="Oxycodone">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Oxycodone</h3>
                            <span class="price">SEK(kr 1900 - kr 2670)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/hydrocodone-bitartrate">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb24d03703b9Hydrocodone.jpg" alt="Hydrocodone Bitartrate" title="Hydrocodone Bitartrate">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Hydrocodone Bitartrate</h3>
                            <span class="price">SEK(kr 43 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/tylenol">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a671d5f426b4tylenol-no-1.jpg" alt="Tylenol" title="Tylenol">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Tylenol</h3>
                            <span class="price">SEK(kr 35 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/actavis-promethazinsirap">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb24db00ebd8actavis prometh codeine cyrup.jpg" alt="Actavis Promethazinsirap" title="Actavis Promethazinsirap">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Actavis Promethazinsirap</h3>
                            <span class="price">SEK(kr 2100 - kr 6500)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/morfin-60mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5bb24c6ee18e0Morphine 60mg.jpg" alt="Morfin 60mg" title="Morfin 60mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Morfin 60mg</h3>
                            <span class="price">SEK(kr 2100 - kr 2830)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/winstrol">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a670a370c02ewinstrol2-300x336.jpg" alt="Winstrol" title="Winstrol">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Winstrol</h3>
                            <span class="price">SEK(kr 1910 - kr 4100)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/trenbolone">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a670abb703513.jpg" alt="Trenbolone" title="Trenbolone">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Trenbolone</h3>
                            <span class="price">SEK(kr 2200 - kr 7000)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/propionate">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a670b1121c21thumb-300x336.jpg" alt="Propionate" title="Propionate">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Propionate</h3>
                            <span class="price">SEK(kr 1950 - kr 5200)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/enanthate">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a670c02b25c7testosterone-enanthate.jpg" alt="Enanthate" title="Enanthate">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Enanthate</h3>
                            <span class="price">SEK(kr 1900 - kr 3200)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/testosterone-cypionate">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a670c291f57bcypionax-by-body-research-200mg-2ml-x-10-amps.jpg" alt="Testosterone Cypionate" title="Testosterone Cypionate">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Testosterone Cypionate</h3>
                            <span class="price">SEK(kr 1970 - kr 5300)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/sustanon">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a670c6f2f806AGP-Sustanon-300-742x557.jpg" alt="Sustanon" title="Sustanon">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Sustanon</h3>
                            <span class="price">SEK(kr 2000 - kr 4900)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/primobolan">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a670cc6957bePrimobolan-Depot-Primobolan-Enanthate-Alphabolin-vial-Methenolone-Enanthate-100mg-10ml-vial-1.jpg" alt="Primobolan" title="Primobolan">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Primobolan</h3>
                            <span class="price">SEK(kr 245 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/omnadren-250-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a670d3adf75b121-202-thickbox.jpg" alt="Omnadren 250 mg" title="Omnadren 250 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Omnadren 250 mg</h3>
                            <span class="price">SEK(kr 65 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/nolvadex">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a670d920e4c3nolvadex1-1024x768__24538_zoom__81241_zoom.jpg" alt="Nolvadex" title="Nolvadex">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Nolvadex</h3>
                            <span class="price">SEK(kr 1863 - kr 2600)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/methyltestosterone-25-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a670dd3eb260Methyltestosterone-Tablets-52.jpg" alt="Methyltestosterone 25 mg" title="Methyltestosterone 25 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Methyltestosterone 25 mg</h3>
                            <span class="price">SEK(kr 1853 - kr 2730)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/lasix-40-mg">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a670e48910e8Lasix40mg-800x800.jpg" alt="Lasix 40 mg" title="Lasix 40 mg">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Lasix 40 mg</h3>
                            <span class="price">SEK(kr 90.73 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/insulin">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a670e6648898994208-8ca6eb3349e1bf8abb43220c1765a59c.jpg" alt="Insulin" title="Insulin">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Insulin</h3>
                            <span class="price">SEK(kr 544.39 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/gamma-hydroxybutyrate">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a6724de65b50dark-side-of-ghb-narcomania-003-1445804990.jpg" alt="Gamma Hydroxybutyrate" title="Gamma Hydroxybutyrate">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Gamma Hydroxybutyrate</h3>
                            <span class="price">SEK(kr 1800 - kr 2800)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/midazolam">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a672508989a4220px-Midazolam.JPG" alt="Midazolam" title="Midazolam">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Midazolam</h3>
                            <span class="price">SEK(kr 381.07 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/lorazepam">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5fc0e5fe6f417lorazepam.jpg" alt="Lorazepam" title="Lorazepam">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Lorazepam</h3>
                            <span class="price">SEK(kr 31.5 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/clonazepam">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a67255ee0bfb5527_5577_1.jpg" alt="Clonazepam" title="Clonazepam">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Clonazepam</h3>
                            <span class="price">SEK(kr 1863 - kr 2790)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/xanax-xr">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a6725fc1d81fxanax-1mg.JPG" alt="Xanax XR" title="Xanax XR">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Xanax XR</h3>
                            <span class="price">SEK(kr 1650 - kr 2400)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/alprazolam">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a672655c1d44Breastfeeding-mother2.jpg" alt="Alprazolam" title="Alprazolam">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Alprazolam</h3>
                            <span class="price">SEK(kr 1810 - kr 2795)</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                  
                <div class="col-md-3">
                    <div class="single_product">
                        <a href="https://www.rxmediciner.com/product/thiopental">
                        <div class="prod_img">
                            <img src="https://www.rxmediciner.com/images/product/5a67273f67848IndianJAnaesth_2012_56_2_168_96335_u1.jpg" alt="Thiopental" title="Thiopental">
                            
                        </div>
                        <div class="prod_title_cart">
                            <h3>Thiopental</h3>
                            <span class="price">SEK(kr 15 )</span>
                            <span class="buybtn">Köp nu</span>
                        </div>
                            </a>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    
    <footer>
    <div class="footer_top_area">
        <div class="footer_top">
            <div class="container">
                <div class="footertop">
                    <div class="col-md-3 col-sm-4">
                        <div class="faddress">
                            <img src="https://www.rxmediciner.com/images/map_dir.png" alt="address" />
                            <h3>Adress</h3>
                            <p>SjÃ¶kallavÃ¤gen 31 817 92 Bergby, Sweden</p>
                        </div>
                    </div>	
                   <!-- <div class="col-md-3 col-sm-4">
                        <div class="faddress">
                            <img src="https://www.rxmediciner.com/images/emcall.png" alt="address" />
                            <h3>Nödsituation ( 24x7 )</h3>
                            <p>Mobile: +46-76894030 <br>Phone : </p>
                        </div>
                    </div>-->	
                    <div class="col-md-3 col-sm-4">
                        <div class="faddress">
                            <img src="https://www.rxmediciner.com/images/mess.png" alt="address" />
                            <h3>Mejla oss</h3>
                            <p>rxmedicinar@gmail.com  <br></p>
                        </div>
                    </div>	
                    <div class="col-md-3 col-sm-3 display-none">
                        <div class="faddress">
                            <img src="https://www.rxmediciner.com/images/clock.png" alt="address" />
                            <h3>Arbetstimmar</h3>
                            <p>24*7</p>
                        </div>
                    </div>	
                </div>
            </div>
        </div>

        <div class="footer_middle">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <ul class="footer-product">
                              
                            <li><a href="https://www.rxmediciner.com/product/ketamine">Ketamine</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/oxycontin-40-mg">OxyContin 40 mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/oxynorm-20mg">OxyNorm 20mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/valium-10-mg">Valium 10 mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/viagra-100-mg">Viagra 100 mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/stesolid-10-mg">Stesolid 10 mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/ambien-zolpidem-10-mg">Ambien Zolpidem 10 mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/stilnox-10-mg">Stilnox 10 mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/zopiclone-7-5-mg">Zopiclone 7.5 mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/stilnoct-10mg">Stilnoct 10mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/kamagra-100mg">Kamagra 100mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/levaxin-150mg">Levaxin 150mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/levitra-20-mg">Levitra 20 Mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/concerta">Concerta</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/dukoral">Dukoral</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/imovane">Imovane</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/tradolan">Tradolan</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/testogel">Testogel</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/dalacin-c">Dalacin C</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/klonazepam-klonopin-2-mg">klonazepam (klonopin 2 mg)</a></li>
                                                   </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer_menu_area">
            <div class="container">
                <div class="footer_menu_in">
                    <div class="col-md-10 col-sm-10">
                        <div class="footer_menu">
                            <nav>
                                <ul>                                
                                    <li class="active"><a href="https://www.rxmediciner.com">Hem</a></li>
                                    <li><a href="https://www.rxmediciner.com/about.php">Om oss</a></li>
                                    <li><a href="https://www.rxmediciner.com/products.php">Alla produkter</a></li>
                                    <li><a href="https://www.rxmediciner.com/blog.php">Bloggar</a></li>
                                    <li><a href="https://www.rxmediciner.com/contact.php">Kontakta oss</a></li>
                                </ul>
                            </nav>
                        </div>					
                    </div>
                    <div class="col-md-2 col-sm-2">
                        <div class="back_top">
                            <a href="javascript:void(0);"><img src="https://www.rxmediciner.com/images/backtop.png" alt="backtop" /></a>
                        </div>		
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer_bottom">
        <div class="container">
            <div class="footer_copyright">
                <div class="col-md-8 col-sm-8">
                    <div class="copy_text">
                        <p>&copy; RX Mediciner 2023. Alla rättigheter förbehållna</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer></body>
    <!-- <script type="text/javascript" src="/js/jquery-1.11.2.min.js?v="></script> -->
<script type="text/javascript" src="https://www.rxmediciner.com/js/bootstrap.min.js?v=1311876042"></script>
<script type="text/javascript" src="https://www.rxmediciner.com/js/jquery.slicknav.min.js?v=1971273053"></script>
<script type="text/javascript" src="https://www.rxmediciner.com/js/owl.carousel.min.js?v=2083776424"></script>
<script type="text/javascript" src="https://www.rxmediciner.com/js/easyResponsiveTabs.js?v=1719365746"></script>
<script type="text/javascript" src="https://www.rxmediciner.com/js/main.js?v=870143203"></script>
<script type="text/javascript" src="https://www.rxmediciner.com/js/toastr.js"></script>
    <script>
jQuery(document).ready(function($) {
    var retrievedObject = null;
    if (localStorage) {
        retrievedObject = localStorage.getItem('__dillionecom');
    } else {
        alert("Error: This browser is still not supported; Please use google chrome!");
    }
    var parsedArray = null;
    if (retrievedObject){
        parsedArray = JSON.parse(retrievedObject);    
    }
    if(parsedArray == null){
        $("#id-cart-value").html(0);
    }else{
        $("#id-cart-value").html(parsedArray.length);
    }
});
var slideModelCart = function(){
    const cartItems = localStorage.getItem('__dillionecom');
    $.ajax({
            type: "POST",
            url: 'https://www.rxmediciner.com/ajax/cartmodal.php',          
            data: {
                myData:cartItems
            },
            cache: false,
            //dataType: "JSON",
            success: function (data) {
                //console.log(data);
                $("#cartModel").html(data);
            },
            error: function(jqXHR, textStatus, errorThrown){
                  alert('error');
              }
    });
};
slideModelCart();
</script>
 <!-- <script type="text/javascript" src="https://www.rxmediciner.com/js/typeahead.js"></script> -->
<script src="//code.jivosite.com/widget/YMYPl516Xh" async></script>    
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5f6ed274f0e7167d0013e867/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<script>
    $(document).ready(function () {
      var url_path = "https://www.rxmediciner.com/";
        $('#src_field').typeahead({
            source: function (query, result) {
                $.ajax({
                    url: url_path+"ajax/read-product.php",
          data: 'query=' + query,            
                    dataType: "json",
                    type: "POST",
                    success: function (data) {
            result($.map(data, function (item) {
              return item;
                        }));
                    }
                });
            }
        });
    });
</script> </html>