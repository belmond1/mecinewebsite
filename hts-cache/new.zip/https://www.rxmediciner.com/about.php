<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/png" href="https://www.rxmediciner.com/images/favicon.png"/>
<script type="text/javascript" src="https://www.rxmediciner.com/js/jquery-1.11.2.min.js?v=676229632"></script>
<script type="text/javascript" src="https://www.rxmediciner.com/js/typeahead.js"></script>
<link rel="stylesheet" type="text/css" href="https://www.rxmediciner.com/css/font-awesome.min.css?v=1985782499" />
<link rel="stylesheet" type="text/css" href="https://www.rxmediciner.com/css/owl.carousel.css?v=1942619433" />
<link rel="stylesheet" type="text/css" href="https://www.rxmediciner.com/css/bootstrap.min.css?v=1177836826" />
<link rel="stylesheet" type="text/css" href="https://www.rxmediciner.com/css/slicknav.min.css?v=327249146" />
<link rel="stylesheet" type="text/css" href="https://www.rxmediciner.com/css/style.css?v=436136759" />
<link rel="stylesheet" type="text/css" href="https://www.rxmediciner.com/css/responsive.css?v=2030151684" />
<link rel="stylesheet" href="https://www.rxmediciner.com/css/toastr.css" />
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-167326560-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-167326560-1');
</script>

<meta name="google-site-verification" content="XOE9tasUYgs1AMPQTnAfXe8GIxNqGWIGkEAZRqTtyRk" />	<title>Hur man bestÃ¤ller medicin online | Rx Mediciner</title>
    <meta name="description" content="Rx Mediciner Ã¤r Sveriges bÃ¤sta onlineapotek. DÃ¤r du kan kÃ¶pa medicin online till mycket lÃ¥gt pris. BestÃ¤ll nu dina lÃ¤kemedel med vÃ¥ra lockade erbjudanden">
    <meta name="keywords" content="kÃ¶p mediciner online, medicin till salu, bestÃ¤ll medicin online, mediciner utan recept" />
</head>
<body>
    <style>
    .typeahead { border: 2px solid #FFF;border-radius: 4px;padding: 8px 12px;max-width: 300px;min-width: 290px;background: rgba(66, 52, 52, 1);color: #FFF;}
    .tt-menu { width:300px; }
    ul.typeahead{margin:0px;padding: 0px;list-style-type: none;}
    ul.typeahead.dropdown-menu2 li a {padding: 10px !important;  border-bottom:#CCC 1px solid;color:#FFF;display: inline-block;width: 100%}
    ul.typeahead.dropdown-menu2 li:last-child a { border-bottom:0px !important; }
    .bgcolor {max-width: 550px;min-width: 290px;max-height:340px;background:url("world-contries.jpg") no-repeat center center;padding: 100px 10px 130px;border-radius:4px;text-align:center;margin:10px;}
    .demo-label {font-size:1.5em;color: #686868;font-weight: 500;color:#FFF;}
    .dropdown-menu2>.active>a, .dropdown-menu2>.active>a:focus, .dropdown-menu2>.active>a:hover{text-decoration: none;background-color: #12aef7;outline: 0;}
    .dropdown-menu2{position: absolute;}
    </style>
<header class="main_header">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <div class="top-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <marquee><b>Vi accepterar betalning med swish</b></marquee>
                </div>
            </div>
        </div>
    </div>
    <div class="header_top_area" style="display:none">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="header_top">
                        <ul>
                            <!--<li><a href="tel:+46-76894030"><i class="fa fa-phone"></i> +46-76894030</a></li>-->
                            <li><a href="mailto:rxmedicinar@gmail.com"><i class="fa fa-envelope"></i> rxmedicinar@gmail.com</a></li>
                        </ul>

                        <ul class="pull-right">
                            <!--<li><a href="mailto:"><i class="fa fa-envelope"></i> </a></li>-->
                            <!--<li><a href="" target="_blank"><i class="fa fa-twitter"></i></a></li>-->
                            <!--<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>-->
                            <!--
                            
                            <li><a href="" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="" target="_blank"><i class="fa fa-youtube-play"></i></a></li>-->
                        </ul>
                    </div>
                </div>
            </div>
        </div>	
    </div>
    <div class="header">
        <div class="container">
            <div class="row">
                    <div class="logo_contact_info_part">
                        <div class="col-md-3">
                            <div class="logo">
                                <a href="https://www.rxmediciner.com"><img src="https://www.rxmediciner.com/images/logo.png" alt="RX Mediciner" title="" /></a>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="cont_info">
                                <div class="week">
                                    <img src="https://www.rxmediciner.com/images/date_icon.png" alt="date" />
                                    <p>Mån till sätta <br><span>24*7</span> </p>
                                </div>
                                <!--<div class="call_us">
                                    <img src="https://www.rxmediciner.com/images/mobile_icon.png" alt="date" />
                                    <p>Ringa oss <br><span>+46-76894030</span> </p>
                                </div>-->
                            </div>
                        </div>
                        <div class="col-md-6">
                            <ul class="booking_cart">
                                <!--
                                                            <li class="book_now"><a href="https://www.rxmediciner.com/login.php">Logga in</a></li>
                                                                -->
                                <li class="book_now"><a href="https://www.rxmediciner.com/contact.php">INQUIRE NU</a></li>
                                <!--<li class="book_now">
                                    <a class="CartSlide" href="javascript:void(0);">Vagn (<small id="id-cart-value">2PCS * KR 10</small>)</a>
                                </li> -->
                            </ul>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    <div class="nav_search_area hidden-xs">
        <div class="container">
            <div class="menu_area">
                <div class="col-md-9">	
                    <div class="nav_part">
                        <nav class="navbar navbar-default">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="main_menu">
                                        <div class="navbar-header">
                                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                                <span class="sr-only">Toggle navigation</span>
                                                <span class="icon-bar"></span>
                                                <span class="icon-bar"></span>
                                                <span class="icon-bar"></span>
                                            </button>	
                                        </div>
                                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                            <ul class="nav navbar-nav">
                                                <li ><a href="https://www.rxmediciner.com">Hem</a></li>
                                                <li class="active"><a href="https://www.rxmediciner.com/about.php">Om oss</a></li>
                                                <li ><a href="javascript:void(0);">kategorier</a>
                                                    <ul class="submenu">
                                                            
                                                        <li><a href="https://www.rxmediciner.com/category/antibiotika">Antibiotika</a></li>
                                                            
                                                        <li><a href="https://www.rxmediciner.com/category/blodtryck-och-diabetiker">Blodtryck och diabetiker</a></li>
                                                            
                                                        <li><a href="https://www.rxmediciner.com/category/smn-och-smnlshet">SÃ¶mn och sÃ¶mnlÃ¶shet</a></li>
                                                            
                                                        <li><a href="https://www.rxmediciner.com/category/anabola-steroider">Anabola Steroider</a></li>
                                                            
                                                        <li><a href="https://www.rxmediciner.com/category/stimulantia">Stimulantia</a></li>
                                                            
                                                        <li><a href="https://www.rxmediciner.com/category/opioider">Opioider</a></li>
                                                            
                                                        <li><a href="https://www.rxmediciner.com/category/depression-och-ngest">Depression och Ã¥ngest</a></li>
                                                                                                            </ul>
                                                </li>
                                                <li ><a href="https://www.rxmediciner.com/products.php">Alla produkter</a></li>
                                                <li ><a href="https://www.rxmediciner.com/blog.php">Bloggar</a></li>
                                                <li ><a href="https://www.rxmediciner.com/contact.php">kontakta oss</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="search">
                        <form class="navbar-form navbar-left" role="search" method="post" action="https://www.rxmediciner.com/search_product.php">
                            <div class="form-group">
                                <input type="text" id="src_field" name="keywords" class="form-control typeahead" placeholder="Skriv här">
                                <input type="submit" id="src_btn" value="Sök"/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>


<div class="box">
<!--    <div class="CartSlide closebtn">X</div>-->
    <div class="box-inner" id="cartModel">Loading...</div>
    </div>    
    <section class="breadcrum">
        <div class="bread_cumbs">
            <div class="container">
                <div class="page_title_breadcumbs">
                    <ul>
                        <li><a href="https://www.rxmediciner.com">Hem</a>»</li>
                        <li>Om oss</li>
                    </ul>
                </div>			
            </div>
        </div>
    </section>
    <section class="about-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <img src="https://www.rxmediciner.com/images/about.jpg" alt="Beställa Läkemedel Online" title="" />
                    <p style="text-align:justify">F&ouml;rst och fr&auml;mst m&aring;ste jag meddela att alla l&auml;kemedel h&auml;r s&auml;ljs utan recept.<br />
Efter &aring;r av f&ouml;rs&auml;ljning p&aring; det m&ouml;rka<strong> </strong>n&auml;tet ins&aring;g jag att det var en av de sv&aring;raste sakerna som h&auml;nde oss h&auml;r i Sverige att f&aring; <strong>l&auml;kemedel</strong> online utan recept. Vi ins&aring;g ocks&aring; att m&aring;nga k&ouml;per fr&aring;n webbplatser i olika delar av Europa. och har senare problem med kostymer. Vi ans&aring;g det ocks&aring; n&ouml;dv&auml;ndigt att vara ett mer anv&auml;ndarv&auml;nligt s&auml;tt att utbilda m&auml;nniskor om s&auml;kerhet.</p>

<p>Vi best&auml;mde oss f&ouml;r att det var dags att bygga en webbplats f&ouml;r att ber&auml;tta hur l&auml;tt det &auml;r f&ouml;r alla p&aring; n&auml;stan vilken budget som helst att k&ouml;pa mediciner online utan recept och f&aring; den levererad i Sverige.<br />
v&aring;ra leveranser tar vanligtvis maximalt 48 timmar, eftersom vi bara levererar inom Sverige.<br />
v&aring;ra l&auml;kemedel &auml;r av h&ouml;gsta kvalitet</p>

<p>Vi erbjuder leverans direkt till ditt hem i Sverige och vi skickar ocks&aring; fr&aring;n Sverige till Norge och Danmark av samma apoteksprodukter som du hittar p&aring; dina apotek i din stad. Vi erbjuder rabatter till personer med h&ouml;ga medicinska tillst&aring;nd samt l&aring;ga priser f&ouml;r &aring;terkommande kunder som best&auml;ller fr&aring;n oss. Vi inbjuder dig att surfa p&aring; v&aring;r webbplats f&ouml;r dina favorit THC-godis och fylla i din best&auml;llning med v&aring;rt online- eller utskrivbara best&auml;llningsformul&auml;r. Din medicinorder via e-post skickas till dig samma dag som vi f&aring;r betalning och du kan vara s&auml;ker p&aring; att leveransen &auml;r privat och s&auml;ker. Ja, du kan k&ouml;pa riktiga droger online med direktreklam och snabb leverans till ditt hem i Sverige.</p>

<p>Om du vill k&ouml;pa medicin f&ouml;r sm&auml;rta, &aring;ngest, s&ouml;mnproblem, ADHDetc kommer vi att &ouml;vertr&auml;ffa dina f&ouml;rv&auml;ntningar med v&aring;rt fantastiska urval och kvalitet och till en kostnad du har r&aring;d med. Med upprepade rekommendationer fr&aring;n v&aring;ra kunder och den goda kvaliteten p&aring; v&aring;ra l&auml;kemedel garanterar vi att du kommer att rekommendera oss till andra, eller snarare komma tillbaka f&ouml;r mer om det beh&ouml;vs. Vi har bara de b&auml;sta produkterna i v&aring;rt apotek. Sedan 2016 har vi varit den b&auml;sta destinationen f&ouml;r alla dina medicinska behov. Vi har varit inom det medicinska omr&aring;det de senaste 6 &aring;ren och har en passion f&ouml;r att verkligen hj&auml;lpa v&aring;ra patienter att uppn&aring; optimal l&auml;ttnad genom v&aring;rt apotek. Vi &auml;r stolta &ouml;ver v&aring;r &ouml;verl&auml;gsna kundtj&auml;nst som hj&auml;lper dig, patienten med alla fr&aring;gor eller problem du har genom varje steg i best&auml;llningsprocessen. Vi s&auml;tter kunden f&ouml;rst och &auml;r stolta &ouml;ver v&aring;ra m&aring;nga upprepningar,</p>

<p>Snabb tillf&ouml;rlitlig leverans:</p>

<p>Vi erbjuder att skicka och sp&aring;ra alla best&auml;llningar. Sp&aring;rningsinformation ges omedelbart n&auml;r best&auml;llningar skickas. Vi skickar dig ocks&aring; ett e-postmeddelande n&auml;r din betalning har mottagits.</p>

<p>Kostnadseffektiv frakt:</p>

<p>Vi skickar det direkt till din d&ouml;rr! Kvalitetsapoteksprodukter! Med dagens bensinpris kan vi spara pengar. Vi erbjuder ocks&aring; rabatter f&ouml;r kunder med h&ouml;gt medicinskt tillst&aring;nd<br />
P&aring;litlighet:</p>

<p>Med de m&aring;nga relationerna med odlare som vi har utvecklat genom &aring;ren ger vi konsekvent kunden en &ouml;verl&auml;gsen produkt. Du kan lita p&aring; oss att vara det &ouml;verl&auml;gsna onlineapoteket.</p>

<p>Vilka &auml;r vi:</p>

<p>Vi &auml;r n&aring;gra m&auml;nniskor, vi har s&aring;lt p&aring; det m&ouml;rka n&auml;tet sedan 2011 och fick senare reda p&aring; hur sv&aring;rt det &auml;r f&ouml;r v&aring;ra m&auml;nniskor h&auml;r i Sverige att f&aring; l&auml;kemedel utan recept.</p>

<p>Vi &auml;r dagens moderna onlineapotek. vi &auml;r stolt det enda apoteket som accepterar swish</p>

<p>Vi ser fram emot att hj&auml;lpa dig med alla dina medicinska behov<br />
Skicka feedback<br />
Historia<br />
Sparad<br />
Bidra</p>                </div>
            </div>
        </div>
    </section>
    <footer>
    <div class="footer_top_area">
        <div class="footer_top">
            <div class="container">
                <div class="footertop">
                    <div class="col-md-3 col-sm-4">
                        <div class="faddress">
                            <img src="https://www.rxmediciner.com/images/map_dir.png" alt="address" />
                            <h3>Adress</h3>
                            <p>SjÃ¶kallavÃ¤gen 31 817 92 Bergby, Sweden</p>
                        </div>
                    </div>	
                   <!-- <div class="col-md-3 col-sm-4">
                        <div class="faddress">
                            <img src="https://www.rxmediciner.com/images/emcall.png" alt="address" />
                            <h3>Nödsituation ( 24x7 )</h3>
                            <p>Mobile: +46-76894030 <br>Phone : </p>
                        </div>
                    </div>-->	
                    <div class="col-md-3 col-sm-4">
                        <div class="faddress">
                            <img src="https://www.rxmediciner.com/images/mess.png" alt="address" />
                            <h3>Mejla oss</h3>
                            <p>rxmedicinar@gmail.com  <br></p>
                        </div>
                    </div>	
                    <div class="col-md-3 col-sm-3 display-none">
                        <div class="faddress">
                            <img src="https://www.rxmediciner.com/images/clock.png" alt="address" />
                            <h3>Arbetstimmar</h3>
                            <p>24*7</p>
                        </div>
                    </div>	
                </div>
            </div>
        </div>

        <div class="footer_middle">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <ul class="footer-product">
                              
                            <li><a href="https://www.rxmediciner.com/product/ketamine">Ketamine</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/oxycontin-40-mg">OxyContin 40 mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/oxynorm-20mg">OxyNorm 20mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/valium-10-mg">Valium 10 mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/viagra-100-mg">Viagra 100 mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/stesolid-10-mg">Stesolid 10 mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/ambien-zolpidem-10-mg">Ambien Zolpidem 10 mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/stilnox-10-mg">Stilnox 10 mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/zopiclone-7-5-mg">Zopiclone 7.5 mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/stilnoct-10mg">Stilnoct 10mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/kamagra-100mg">Kamagra 100mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/levaxin-150mg">Levaxin 150mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/levitra-20-mg">Levitra 20 Mg</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/concerta">Concerta</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/dukoral">Dukoral</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/imovane">Imovane</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/tradolan">Tradolan</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/testogel">Testogel</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/dalacin-c">Dalacin C</a></li>
                                
                            <li><a href="https://www.rxmediciner.com/product/klonazepam-klonopin-2-mg">klonazepam (klonopin 2 mg)</a></li>
                                                   </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer_menu_area">
            <div class="container">
                <div class="footer_menu_in">
                    <div class="col-md-10 col-sm-10">
                        <div class="footer_menu">
                            <nav>
                                <ul>                                
                                    <li class="active"><a href="https://www.rxmediciner.com">Hem</a></li>
                                    <li><a href="https://www.rxmediciner.com/about.php">Om oss</a></li>
                                    <li><a href="https://www.rxmediciner.com/products.php">Alla produkter</a></li>
                                    <li><a href="https://www.rxmediciner.com/blog.php">Bloggar</a></li>
                                    <li><a href="https://www.rxmediciner.com/contact.php">Kontakta oss</a></li>
                                </ul>
                            </nav>
                        </div>					
                    </div>
                    <div class="col-md-2 col-sm-2">
                        <div class="back_top">
                            <a href="javascript:void(0);"><img src="https://www.rxmediciner.com/images/backtop.png" alt="backtop" /></a>
                        </div>		
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer_bottom">
        <div class="container">
            <div class="footer_copyright">
                <div class="col-md-8 col-sm-8">
                    <div class="copy_text">
                        <p>&copy; RX Mediciner 2023. Alla rättigheter förbehållna</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer></body>
    <!-- <script type="text/javascript" src="/js/jquery-1.11.2.min.js?v="></script> -->
<script type="text/javascript" src="https://www.rxmediciner.com/js/bootstrap.min.js?v=1544520505"></script>
<script type="text/javascript" src="https://www.rxmediciner.com/js/jquery.slicknav.min.js?v=1914616544"></script>
<script type="text/javascript" src="https://www.rxmediciner.com/js/owl.carousel.min.js?v=934435872"></script>
<script type="text/javascript" src="https://www.rxmediciner.com/js/easyResponsiveTabs.js?v=1788342462"></script>
<script type="text/javascript" src="https://www.rxmediciner.com/js/main.js?v=237584667"></script>
<script type="text/javascript" src="https://www.rxmediciner.com/js/toastr.js"></script>
    <script>
jQuery(document).ready(function($) {
    var retrievedObject = null;
    if (localStorage) {
        retrievedObject = localStorage.getItem('__dillionecom');
    } else {
        alert("Error: This browser is still not supported; Please use google chrome!");
    }
    var parsedArray = null;
    if (retrievedObject){
        parsedArray = JSON.parse(retrievedObject);    
    }
    if(parsedArray == null){
        $("#id-cart-value").html(0);
    }else{
        $("#id-cart-value").html(parsedArray.length);
    }
});
var slideModelCart = function(){
    const cartItems = localStorage.getItem('__dillionecom');
    $.ajax({
            type: "POST",
            url: 'https://www.rxmediciner.com/ajax/cartmodal.php',          
            data: {
                myData:cartItems
            },
            cache: false,
            //dataType: "JSON",
            success: function (data) {
                //console.log(data);
                $("#cartModel").html(data);
            },
            error: function(jqXHR, textStatus, errorThrown){
                  alert('error');
              }
    });
};
slideModelCart();
</script>
 <!-- <script type="text/javascript" src="https://www.rxmediciner.com/js/typeahead.js"></script> -->
<script src="//code.jivosite.com/widget/YMYPl516Xh" async></script>    
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5f6ed274f0e7167d0013e867/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<script>
    $(document).ready(function () {
      var url_path = "https://www.rxmediciner.com/";
        $('#src_field').typeahead({
            source: function (query, result) {
                $.ajax({
                    url: url_path+"ajax/read-product.php",
          data: 'query=' + query,            
                    dataType: "json",
                    type: "POST",
                    success: function (data) {
            result($.map(data, function (item) {
              return item;
                        }));
                    }
                });
            }
        });
    });
</script> </html>